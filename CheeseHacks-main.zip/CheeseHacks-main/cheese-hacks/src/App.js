import React from 'react'

import Home from './components/Home';
import Login from './components/Authentication/Login';
import Register from './components/Authentication/Register';
import Profile from './components/Profile'
import CreateJobs from './components/CreateJobs'
import Explore from './components/Explore'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import './firebase';



require('dotenv').config()

export default function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/login">
            <Login />
          </Route>
          <Route path="/explore">
            <Explore />
          </Route>
          <Route path="/register">
            <Register />
          </Route>
          <Route path="/Profile">
            <Profile />
          </Route>
          <Route path="/Home">
            <Home />
          </Route>
          <Route path="/CreateJobs">
            <CreateJobs />
          </Route>
          <Route path = "/">
            <Login />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}
