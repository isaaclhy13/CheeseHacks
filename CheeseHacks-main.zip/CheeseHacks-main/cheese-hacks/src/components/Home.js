import React, { useEffect, useState } from 'react';
import { collection, where, query, getDoc, doc } from "firebase/firestore";
import { db } from '../firebase';
import companylogo from '../companylogo.PNG'
import {
    BrowserRouter as Router,
    Link
} from "react-router-dom";
import { Typography, Card, CardContent } from '@material-ui/core';
import { getAuth } from '@firebase/auth';


export default function Home({ ...props }) {
    const [currentTasks, setCurrentTasks] = useState([]);
    const [previousTasks, setPreviousTasks] = useState([]);

    const [sevenDaySum, setSevenDaySum] = useState(0);
    const [totalSum, setTotalSum] = useState(0);
    const [thirtyDaySum, setThirtyDaySum] = useState(0);

    useEffect(() => {
        let sevenDaySumTemp = 0;
        let totalSumTemp = 0;
        let thirtyDaySumTemp = 0;
        const d = new Date();
        for(let i = 0; i < previousTasks.length; i += 1) {
            console.log(previousTasks[i])
            totalSumTemp += previousTasks[i].jobPay;
            if(Math.abs(d.getTime() - parseInt(previousTasks[i].jobDate)) <= 604800000) {
                sevenDaySumTemp += parseInt(previousTasks[i].jobPay);
            }
            if(Math.abs(d.getTime() - parseInt(previousTasks[i].jobDate)) <= 2592000000) {
                thirtyDaySumTemp += parseInt(previousTasks[i].jobPay);
            }
        }
        setSevenDaySum(sevenDaySumTemp);
        setTotalSum(totalSumTemp);
        setThirtyDaySum(thirtyDaySumTemp);
    },[previousTasks.length])
    useEffect(() => {
        const auth = getAuth();
        const docRef = doc(db,"users",auth.currentUser.uid);
        const tempPreviousTasks = [];
        const tempCurrentTasks = [];
        getDoc(docRef)
            .then((d) => {
                //console.log(d.data())
                const job = d.data().currJobs;
                tempCurrentTasks.push(job);
                setCurrentTasks(tempCurrentTasks);
                setPreviousTasks(tempPreviousTasks);
            })
    }, []);
    return (
        <div style={{ margin: 0, padding: 0 }}>
            <div style={{ width: '100vw', height: '100vh' }}>
                <div style={{ height: "13vh", width: '100vw', background: '#445768', flexDirection: 'row', display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{width:'20vw', height:'13vh', flex:'left', alignItems:'center', justifyContent:'center',paddingLeft:'2vw'}}>
                        <img src={companylogo} style={{width:'13vw', height:'12vh',opacity:1}} />
                    </div>
                    <div style={{ width: '60vw', height: '13vh', flex: 'right' }}>
                        <ul style={{ marginTop: 0, height: '13vh', flexDirection: 'row', display: 'flex', justifyContent: 'space-arounds', alignContent: 'center', listStyle: 'none' }}>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                                <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Explore">Explore</Link>
                            </li>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                                <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Home">Dashboard</Link>
                            </li>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                                <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/CreateJobs">Create a Job</Link>
                            </li>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                                <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Profile">Profile</Link>
                            </li>
                        </ul>
                    </div>
                </div>
                <div style={{ height: "50vh", width: '75vw', paddingLeft: '12.5vw', paddingRight: '12.5vw', justifyContent: 'space-evenly', flexDirection: 'row', display: 'flex', alignItems: 'center' }}>
                    <div style={{ height: '40vh', width: '25vw', display: 'flex', justifyContent: 'center', flexDirection: 'column', textAlign: 'center' }}>
                        <p style={{ fontSize: '7vh', margin: 0 }}>Past 7 days</p>

                        <p style={{ color: '#445768', fontSize: '5vh', margin: '2vh' }}>${sevenDaySum}</p>
                    </div>
                    <div style={{ height: '40vh', width: '25vw', display: 'flex', flexDirection: 'row', position: 'relative', alignItems: 'center' }}>
                        <div style={{ height: '30vh', width: '0.2vw', background: '#e0e0e0' }}></div>
                        <div style={{ height: '40vh', width: '25vw', display: 'flex', justifyContent: 'center', flexDirection: 'column', textAlign: 'center' }}>
                            <p style={{ fontSize: '9vh', margin: 0 }}>Total</p>
                            <h3 style={{ color: '#445768', margin: 0 }}>Until Present</h3>
                            <p style={{ color: '#445768', fontSize: '7vh', margin: '2vh' }}>${totalSum}</p>
                        </div>
                        <div style={{ height: '30vh', width: '0.2vw', background: '#e0e0e0' }}></div>
                    </div>
                    <div style={{ height: '40vh', width: '25vw', display: 'flex', justifyContent: 'center', flexDirection: 'column', textAlign: 'center' }}>
                        <p style={{ fontSize: '7vh', margin: 0 }}>Past 30 days</p>

                        <p style={{ color: '#445768', fontSize: '5vh', margin: '2vh' }}>${thirtyDaySum}</p>
                    </div>
                </div>

                <div style={{ width: "90vw", height: "20vh", marginLeft: '5vw', marginRight: '5vw' }}>
                    <h2 style={{}}>Current Tasks</h2>
                    {currentTasks.length !== 0 ?
                        <div style={{ background: '#F5F5F5', height: '20vh' }}>
                            {
                                currentTasks.map((e) => (
                                    <Card variant="outlined" style={{ width: '500px' }}>
                                        <CardContent style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                                            <Typography>Name: {e.name}</Typography>
                                            <Typography>Payout: $ {e.pay}</Typography>
                                          
                                        </CardContent>
                                    </Card>
                                ))
                            }
                        </div>
                        :
                        <div style={{ width: "90vw", height: "10vh", display: 'flex', justifyContent: 'center', textAlign: 'center', color: '#545454', flexDirection: 'column' }}>
                            <h3 style={{ margin: 0 }}>You have no current jobs!</h3>
                            <h4 style={{ margin: '1vh', color: '#e1e1e1' }}>Explore jobs now</h4>
                        </div>

                    }
                </div>

                <div style={{ width: "90vw", height: "20vh", marginBottom: '5vw', marginLeft: '5vw', marginRight: '5vw' }}>
                    <h2 style={{}}>Past Tasks</h2>
                    {previousTasks.length !== 0 ?
                        <div>
                            {
                                previousTasks.map((e) => (
                                    <Card variant="outlined" style={{ width: '500px' }}>
                                        <CardContent style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                                            <Typography>Name: {e.name}</Typography>
                                            <Typography>Payout: $ {e.payout}</Typography>
                                            <Typography>Creator: {e.creator}</Typography>
                                        </CardContent>
                                    </Card>
                                ))
                            }
                        </div>
                        :
                        <div style={{ width: "90vw", height: "10vh", display: 'flex', justifyContent: 'center', textAlign: 'center', color: '#545454', flexDirection: 'column' }}>
                            <h3 style={{ margin: 0 }}>You have no past jobs!</h3>
                        </div>

                    }
                </div>

                <div >
                    
                </div>
            </div>
        </div>
    );
}