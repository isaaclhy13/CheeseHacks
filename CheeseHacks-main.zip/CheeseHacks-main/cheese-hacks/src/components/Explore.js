import React from 'react';
import GoogleApiWrapper from './GoogleApiWrapper'
import { Button, TextField } from'@mui/material'
import Geocode from "react-geocode";
import { useHistory } from 'react-router-dom';
import companylogo from '../companylogo.PNG'
import { collection, where, query, getDoc, getDocs, doc, setDoc, updateDoc, arrayUnion } from "firebase/firestore";
import { db } from '../firebase';
import { getAuth } from 'firebase/auth';
import {
    BrowserRouter as Router,
    Link
} from "react-router-dom";
import Alert from '@mui/material/Alert';


export default function Explore({ ...props }) {
   const history = useHistory();
    const auth = getAuth();
    const [currJob, setCurrJob] = React.useState({});
    const [lat, setLat] = React.useState(43.071018);
    const [long, setLong] = React.useState(-89.407204);
    const [address, setAddress] = React.useState("");
    const [showSuccess, setShowSuccess] = React.useState(false);
    const [properAddress, setProperAddress] = React.useState("");

    Geocode.setApiKey("AIzaSyAW6DgyjaIdZNbBeu6lWEGufpu2v_SBIlU");

    const getLatLong = () => { 
        Geocode.fromAddress(address).then(
        (response) => {
          const { lat, lng } = response.results[0].geometry.location;
          setLat(lat)
          setLong(lng)
        },
        (error) => {
          console.error(error);
        }
      );
      getProperAddress()
    }

    const getProperAddress = () => { 
        Geocode.fromLatLng(lat, long).then(
            (response) => {
              const addy = response.results[0].formatted_address;
              setProperAddress(addy)
            },
            (error) => {
              console.error(error);
            }
          );
    }

    const getData = (val) => {
        setCurrJob(val)
    }

    const _handleTextFieldChange = (e) => {
        setAddress(e.target.value);
    }

    const acceptJob = () => {
      if(currJob.id != null || currJob.id != undefined){
        const userRef = collection(db, 'users');
        setShowSuccess(true);
       
        updateDoc(doc(userRef,auth.currentUser.uid), {
          currJobs: { pay: currJob.jobPay, name: currJob.jobName}
        });
    }
    }

    const scrollToBottom = () =>{ 
      window.scrollTo({ 
        top: document.documentElement.scrollHeight, 
        behavior: 'smooth'
      }); 
    };  

    const goToCreateJobs = () => {
      history.push('/CreateJobs');
    }

    return (
      <div style={{ margin: 0, padding: 0 }}>
          <div style={{ width: '100vw', height: '100vh' }}>
              <div style={{ height: "13vh", width: '100vw', background: '#445768', flexDirection: 'row', display: 'flex', justifyContent: 'space-between' }}>
                  <div style={{ width: '20vw', height: '13vh', flex: 'left', alignItems: 'center', justifyContent: 'center', paddingLeft: '2vw' }}>
                      <img src={companylogo} style={{ width: '13vw', height: '12vh', opacity: 1 }} />
                  </div>
                  <div style={{ width: '60vw', height: '13vh', flex: 'right' }}>
                      <ul style={{ marginTop: 0, height: '13vh', flexDirection: 'row', display: 'flex', justifyContent: 'space-arounds', alignContent: 'center', listStyle: 'none' }}>
                          <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                          <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Explore">Explore</Link>
                          </li>
                          <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                          <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Home">Dashboard</Link>
                          </li>
                          <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                          <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/CreateJobs">Create a Job</Link>
                          </li>
                          <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                          <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Profile">Profile</Link>
                          </li>
                      </ul>
                  </div>
              </div> 
              <div style={{ flex:1, display:'flex', justifyContent:'center', alignItems:'center', height:'87vh', textAlign:'center', alignContent:'center', margin: 'auto'}}>
                <p style={{fontSize:'10vh', fontWeight:800, color:'#445768', paddingBottom:0,}}> With the community, <br/> <p style={{color:'#6C87A0', marginTop:0}}>for the community.</p></p>
                <Button onClick={()=> scrollToBottom() } variant="outlined" style={{position:'absolute', bottom: '10vh', left:'40vw' }} >Explore</Button>
                <Button onClick={()=> goToCreateJobs() } variant="contained" color="primary" style={{position:'absolute', bottom: '10vh', left:'50vw' }} > Create </Button>
              </div>           
            
          </div>
          <div style={{width:'90vw', height:'80vh', position:'relative', paddingBottom:'10vh'}}>
            { showSuccess ? 
          <Alert severity="success">Success! Job has been added to your current tasks!</Alert>
          : null
          }
              <GoogleApiWrapper sendData={getData} lat={lat} lng={long} style={{width:'80vw'}} />
              <Button variant="contained" onClick={()=>acceptJob()} style={{position:'absolute', bottom: '10vh', left:'45vw' }} >Accept job</Button>
            </div>
            
            {/* <h1>{properAddress}</h1>
            <h1>{lat}</h1>
            <h1>{long}</h1>
            <Button variant="contained" onClick={getLatLong} >Set Current Location</Button>
            <TextField id="outlined-basic" label="Outlined" variant="outlined" 
            value={address} onChange={_handleTextFieldChange}/> */}

      </div>
    );
}


