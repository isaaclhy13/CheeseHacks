import React, { Component } from 'react';
import { Map, GoogleApiWrapper, Marker, InfoWindow } from 'google-maps-react';
import InfoCard from './InfoCard';
import { collection, where, query, getDoc, getDocs } from "firebase/firestore";
import { db } from '../firebase';
import companylogo from '../companylogo.PNG'
import {
    BrowserRouter as Router,
    Link
} from "react-router-dom";
import { Typography, Card, CardContent } from '@material-ui/core';
import { getAuth } from '@firebase/auth';

const mapStyles = {
    width: '90vw',
    height: '80vh',
    marginLeft: '5vw',
    borderRadius: '1vw',
    marginTop: '3vh'
};

export class MapContainer extends Component {
    state = {
        jobs: [],
        showingInfoWindow: false,
        activeMarker: {},
        selectedPlace: {},
        currentObj: {}
    }

    setCurrentObj = (id) => {
        let obj = this.state.jobs.find(o => o.id === id);
        console.log("Test2",obj)
        this.props.sendData(obj);
        this.setState({
            ...this.state,
            currentObj: obj
        });
    }

    onMarkerClick = (props, marker, e) => {
        this.setState({
            selectedPlace: props,
            activeMarker: marker,
            showingInfoWindow: true,
        });
        this.setCurrentObj(props.name)
    }


    onClose = () => {
        if (this.state.showingInfoWindow) {
            this.setState({
                showingInfoWindow: false,
                activeMarker: null
            });
        }
        this.props.sendData({});
    };

    componentDidMount = () => {
        const jobsRef = collection(db, 'jobs');
        const auth = getAuth();
        // console.log("uid",auth.currentUser.uid);
        const q = query(jobsRef, where("completed", "==", false))
        const querySnapshot = getDocs(q)
            .then((d) => {
                let arr = []
                d.forEach((doc) => {
                    arr.push({ id: doc.id, ...doc.data() })
                })
                console.log("test",arr)
                this.setState({ jobs: arr })
            })
    }

    render() {
        

        return (
            <Map
                google={this.props.google}
                zoom={14}
                style={mapStyles}
                initialCenter={
                    {
                        lat: 43.071018,
                        lng: -89.407204
                    }
                }
                center={
                    {
                        lat: this.props.lat,
                        lng: this.props.lng
                    }
                }
            >
                {
                    this.state.jobs.map((e) => (

                        <Marker
                            position={{
                                lat: e.lat,
                                lng: e.long
                            }}
                            onClick={this.onMarkerClick}
                            name={e.id}
                        />
                    ))
                }

                {
                    this.state.jobs.map((e) => (
                        <InfoWindow
                            marker={this.state.activeMarker}
                            visible={this.state.showingInfoWindow}
                            style={{ height: 200, width: 200 }}
                            onClose={this.onClose}
                        >
                            <InfoCard info={this.state.currentObj} />
                        </InfoWindow>
                    ))
                }

            </Map>
        );
    }
}

export default GoogleApiWrapper({
    apiKey: 'AIzaSyAW6DgyjaIdZNbBeu6lWEGufpu2v_SBIlU'
})(MapContainer);