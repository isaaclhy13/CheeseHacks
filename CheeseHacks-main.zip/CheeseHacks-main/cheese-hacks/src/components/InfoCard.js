import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

export default function InfoCard(props) {
    // console.log("HERE",props.info.startTime)
    return (
      <Card sx={{ minWidth: 275 }}>
        <CardContent>
          <Typography variant="h4" component="div">
            {props.info.jobName}
          </Typography>
           <Typography variant="body1" color="text.secondary">
            {props.info.startTime}
          </Typography>
          <Typography variant="body1" color="text.secondary">
            {props.info.endTime}
          </Typography> 
          <Typography variant="body2">
              <br/>
            {props.info.jobDescription}
          </Typography>
        </CardContent>
        <CardActions>
          <Button size="large">$ {props.info.jobPay}</Button>
        </CardActions>
      </Card>
    );
  }