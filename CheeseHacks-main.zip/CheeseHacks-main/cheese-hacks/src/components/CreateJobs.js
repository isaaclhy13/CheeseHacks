import React, { useEffect, useState } from 'react';
import { collection, where, query, getDoc, getDocs, doc, setDoc } from "firebase/firestore";
import { Container, Typography, Input, Button, TextField } from '@material-ui/core';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Geocode from "react-geocode";
import moment from "moment";
import Grid from '@mui/material/Grid';
import Alert from '@mui/material/Alert';


import { db } from '../firebase';
import { getAuth } from 'firebase/auth';
import companylogo from '../companylogo.PNG'
import {
    BrowserRouter as Router,
    Link
} from "react-router-dom";


export default function CreateJobs({ ...props }) {
    const auth = getAuth();
    const [jobName, setJobName] = useState("");
    const [jobDate, setJobDate] = useState("");
    const [jobPay, setJobPay] = useState("");
    const [jobEmployer, setJobEmployer] = useState("");
    const [jobDescription, setJobDescription] = useState("");
    
    const [showSuccess, setShowSuccess] = React.useState(false);

    // const [jobLocation, setJobLocation] = useState("");
    // const [jobCategory, setJobCategory] = useState("");
    const [startTime, setStartTime] = useState("2014-09-15 09:00:00");
    const [endTime, setEndTime] = useState("2014-09-16 09:00:00");

    const [address, setAddress] = useState("");
    const [properAddress, setProperAddress] = useState("");
    const [lat, setLat] = useState(43.071018);
    const [long, setLong] = useState(-89.407204);

    const [age, setAge] = useState('');

    const handleChange2 = (newValue) => {
        setStartTime(newValue.target.value);
    };

    const handleChange3 = (newValue) => {
        setEndTime(newValue.target.value);
    };

    const handleChange = (event) => {
        setAge(event.target.value);
    };

    Geocode.setApiKey("AIzaSyAW6DgyjaIdZNbBeu6lWEGufpu2v_SBIlU");

    const getLatLong = () => {
        Geocode.fromAddress(address).then(
            (response) => {
                const { lat, lng } = response.results[0].geometry.location;
                setLat(lat)
                setLong(lng)
            },
            (error) => {
                console.error(error);
            }
        );
        getProperAddress()
    }

    const getProperAddress = () => {
        Geocode.fromLatLng(lat, long).then(
            (response) => {
                const addy = response.results[0].formatted_address;
                setProperAddress(addy)
            },
            (error) => {
                console.error(error);
            }
        );
    }

    const _handleTextFieldChange = (e) => {
        setAddress(e.target.value);
    }

    // const [currentTasks, setCurrentTasks] = useState([]);
    // const [previousTasks, setPreviousTasks] = useState([]);
    // useEffect(() => {
    //     const jobsRef = collection(db, 'jobs');
    //     const q = query(jobsRef, where("userAssigned", "==", "ID"))
    //     const tempPreviousTasks = [];
    //     const tempCurrentTasks = [];
    //     const querySnapshot = getDocs(q)
    //         .then((d) => {
    //             d.forEach((doc) => {
    //                 const currentData = doc.data();
    //                 if (currentData.completed === true) {
    //                     tempPreviousTasks.push(currentData);
    //                 } else {
    //                     tempCurrentTasks.push(currentData);
    //                 }
    //             })
    //             setCurrentTasks(tempCurrentTasks);
    //             setPreviousTasks(tempPreviousTasks);
    //         })
    // }, []);

    const veryifyInput = () => {
        console.log(auth.currentUser);
        if (jobName == undefined || jobDate == null || jobPay == null || jobEmployer == null || jobDescription == null || auth.currentUser === null
            || properAddress == null || age == null || startTime == null || endTime == null
        ) {
            alert("Input incorrect");
        }
        else {
            console.log({
                jobName: jobName,
                jobDate: jobDate,
                jobPay: jobPay,
                jobEmployer: jobEmployer,
                jobDescription: jobDescription
            });

            var momentDate1 = moment(startTime);
            var momentDate2 = moment(endTime);

            const usersRef = collection(db, "jobs");
            setDoc(doc(usersRef, new Date().getTime().toString()), {
                jobName: jobName,
                jobDate: jobDate,
                jobPay: jobPay,
                jobEmployer: jobEmployer,
                jobDescription: jobDescription,

                jobLocation: properAddress,
                jobCateogry: age,
                startTime: startTime,
                endTime: endTime,

                lat: lat,
                long: long,
                creator: auth.currentUser.uid,

                userAssigned: "",
                completed: false
            });
        }
    }
    return (
        <div style={{ margin: 0, padding: 0 }}>
            <div style={{ height: "13vh", width: '100vw', background: '#445768', flexDirection: 'row', display: 'flex', justifyContent: 'space-between' }}>
                <div style={{ width: '20vw', height: '13vh', flex: 'left', alignItems: 'center', justifyContent: 'center', paddingLeft: '2vw' }}>
                    <img src={companylogo} style={{ width: '13vw', height: '12vh', opacity: 1 }} />
                </div>
                <div style={{ width: '60vw', height: '13vh', flex: 'right' }}>
                    <ul style={{ marginTop: 0, height: '13vh', flexDirection: 'row', display: 'flex', justifyContent: 'space-arounds', alignContent: 'center', listStyle: 'none' }}>
                        <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{ color: 'white', fontSize: '3vh', textDecoration: 'none' }} to="/Explore">Explore</Link>
                        </li>
                        <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{ color: 'white', fontSize: '3vh', textDecoration: 'none' }} to="/Home">Dashboard</Link>
                        </li>
                        <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{ color: 'white', fontSize: '3vh', textDecoration: 'none' }} to="/CreateJobs">Create a Job</Link>
                        </li>
                        <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{ color: 'white', fontSize: '3vh', textDecoration: 'none' }} to="/Profile">Profile</Link>
                        </li>
                    </ul>
                </div>
            </div>



            <div style={{ width: '90vw', textAlign: 'center', paddingLeft: '5vw', paddingRight: '5vw', marginTop: '3vw' }}>
            { showSuccess ? 
          <Alert severity="success">Success! Job has been added to your current tasks!</Alert>
          : null
          }
                <h1 style={{ color: '#445768' }}>Create a job!</h1>

                <div style={{ width: '90vw', height: '150vh', flexDirection: 'column', justifyContent: 'space-between', marginTop: '5vh' }}>

                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '7vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Name :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '7vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            <Input onChange={(value) => setJobName(value.target.value)} style={{ height: '5vh', width: '20vw', border: '1px solid #e0e0e0', paddingLeft: '1vw', float: 'left', }} />
                        </div>
                    </div>
                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '7vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Date :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '7vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            <Input onChange={(value) => setJobDate(value.target.value)} style={{ height: '5vh', width: '20vw', border: '1px solid #e0e0e0', paddingLeft: '1vw', float: 'left', }} />
                        </div>
                    </div>
                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '7vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Pay ($USD) :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '7vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            <Input onChange={(value) => setJobPay(value.target.value)} style={{ height: '5vh', width: '20vw', border: '1px solid #e0e0e0', paddingLeft: '1vw', float: 'left', }} />
                        </div>
                    </div>
                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '7vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Employeer :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '7vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            <Input onChange={(value) => setJobEmployer(value.target.value)} style={{ height: '5vh', width: '20vw', border: '1px solid #e0e0e0', paddingLeft: '1vw', float: 'left', }} />
                        </div>
                    </div>
                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '20vh', marginTop: '3vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Description :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '20vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            <Input onChange={(value) => setJobDescription(value.target.value)} style={{ height: '20vh', width: '20vw', border: '1px solid #e0e0e0', paddingLeft: '1vw', float: 'left', }} />
                        </div>
                    </div>



                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '20vh', marginTop: '3vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Location :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '20vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            <TextField id="outlined-basic" label="Outlined" variant="outlined"
                                value={address} onChange={_handleTextFieldChange} />

                            <h5>{properAddress}</h5>
                            <Button variant="contained" onClick={getLatLong} >Set Current Location</Button>

                        </div>
                    </div>

                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '20vh', marginTop: '3vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Category :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '20vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            {/* <Input  onChange ={(value)=>setJobCategory(value.target.value)} style={{height:'20vh', width:'20vw', border:'1px solid #e0e0e0', paddingLeft:'1vw', float:'left', }}/> */}
                            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
                                {/* <InputLabel id="demo-simple-select-standard-label">Age</InputLabel> */}
                                <Select
                                    labelId="demo-simple-select-standard-label"
                                    id="demo-simple-select-standard"
                                    value={age}
                                    onChange={handleChange}
                                    label="Age"
                                >
                                    <MenuItem value="">
                                        <em>Other</em>
                                    </MenuItem>
                                    <MenuItem value={"Yardwork"}>Yardwork</MenuItem>
                                    <MenuItem value={"Household"}>Household</MenuItem>
                                    <MenuItem value={"Pet-related"}>Pet-related</MenuItem>
                                    <MenuItem value={"Maintenance"}>Maintenance</MenuItem>
                                    <MenuItem value={"Seasonal"}>Seasonal</MenuItem>
                                </Select>
                            </FormControl>
                        </div>
                    </div>

                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '20vh', marginTop: '3vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>Start time :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '20vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            {/* <Input  onChange ={(value)=>setStartTime(value.target.value)} style={{height:'20vh', width:'20vw', border:'1px solid #e0e0e0', paddingLeft:'1vw', float:'left', }}/> */}
                            <TextField id="outlined-basic" label="Outlined" variant="outlined"
                                value={startTime} onChange={handleChange2} />
                        </div>
                    </div>

                    <div style={{ flexDirection: 'row', justifyContent: 'space-between', display: 'flex', width: '90vw', height: '20vh', marginTop: '3vh' }}>
                        <div style={{ width: '44vw', height: '7vh', alignItems: 'center', justifyContent: 'end', alignContent: 'center', display: 'flex' }}>
                            <h2 style={{ float: 'right', color: '#445768' }}>End time :</h2>
                        </div>
                        <div style={{ width: '44vw', height: '20vh', display: 'flex', alignContent: 'center', justifyContent: 'start', alignItems: 'center' }}>
                            {/* <Input  onChange ={(value)=>setStartTime(value.target.value)} style={{height:'20vh', width:'20vw', border:'1px solid #e0e0e0', paddingLeft:'1vw', float:'left', }}/> */}
                            <TextField id="outlined-basic" label="Outlined" variant="outlined"
                                value={endTime} onChange={handleChange3} />
                        </div>
                    </div>

                </div>







            </div>
            <div style={{ width: '100vw', justifyContent: 'center', display: 'flex' }}>
                <Button onClick={() => {veryifyInput(); setShowSuccess(true);}} style={{ width: "15vw", height: '6vh', alignSelf: 'center', border: 'none', borderRadius: '0.5vw', background: '#445768', alignSelf: 'center', display: 'flex', justifyContent: 'center' }}>
                    <p style={{ fontSize: '1.5vw', padding: 0, margin: 'auto', color: 'white' }}>Create</p>
                </Button>
            </div>
        </div>

    );
}