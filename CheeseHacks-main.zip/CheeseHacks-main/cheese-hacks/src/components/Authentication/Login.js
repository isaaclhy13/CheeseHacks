import React, { useState } from 'react';
import { Container, FormControl, InputLabel, Typography, Input, Button } from '@material-ui/core';
import Sidebar from './Sidebar';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { useHistory } from 'react-router-dom';
import '../../firebase';
const auth = getAuth();
export default function Login({ ...props }) {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const history = useHistory();
    const handleLogin = () => {
        signInWithEmailAndPassword(auth, username, password)
            .then(() => {
                history.push('/explore')
            })
            .catch((error) => {
                alert("Wrong password or user not found.")
            })
    }

    return (
        <Container style={{
            height: '900px',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-start',
            padding: 0,
            margin: 0,
        }}>
            <Sidebar />
            <Container>
                <Container style={{
                    width: '500px',
                    marginTop: '200px'
                }}>
                    <Typography variant="h3" style={{ paddingLeft: '43px', color: '#A7A7A7' }}>
                        Login with Lokal
                    </Typography>
                    <Container style={{ marginTop: '30px', height: '110px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="username">Username</InputLabel>
                                <Input onChange={(e) => setUsername(e.target.value)} id="username" aria-describedby="username" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="password">Password</InputLabel>
                                <Input type="password" onChange={(e) => setPassword(e.target.value)} id="password" aria-describedby="password" />
                            </FormControl>
                        </Container>
                    </Container>
                    <Container style={{ marginTop: '30px', display: 'flex', flexDirection: 'row', justifyContent: 'flex-end' }}>
                        <Button onClick={() => history.push('/register')} style={{ marginRight: '20px' }} variant="outlined" color="primary">Sign Up</Button>
                        <Button onClick={() => handleLogin()} variant="contained" color="primary">Login</Button>
                    </Container>
                </Container>
            </Container>
        </Container>
    );
}