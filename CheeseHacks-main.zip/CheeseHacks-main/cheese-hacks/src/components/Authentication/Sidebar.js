import React from 'react';
import { Container, FormControl, InputLabel, Typography, Input, Button } from '@material-ui/core';

export default function App() {
    return (
        <Container style={{
            color: 'white',
            width: '400px',
            backgroundColor: '#445768',
            textAlign: 'center',
            paddingTop: '200px',
        }}>
            <Typography variant="h2" >
                Lokal
        </Typography>
            <Container style={{ textAlign: 'left' }}>
                <Typography variant="subtitle1" style={{ padding: '20px' }}>
                    Post and pick up jobs in your neighborhood!
            </Typography>
            </Container>
        </Container>
    );
}