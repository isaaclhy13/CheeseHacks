import React, { useState } from 'react';
import { Container, FormControl, InputLabel, Typography, Input, Button } from '@material-ui/core';
import Sidebar from './Sidebar';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { db } from '../../firebase'
import '../../firebase';
import { useHistory } from 'react-router-dom';
import { collection, doc, setDoc } from 'firebase/firestore';
export default function Register({ ...props }) {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [imageLink, setImageLink] = useState("");
    const [description, setDescription] = useState("");
    const [age, setAge] = useState("");
    const history = useHistory();
    const handleRegister = () => {
        const auth = getAuth();
        createUserWithEmailAndPassword(auth, username, password)
            .then((user) => {
                const usersRef = collection(db, "users");
                setDoc(doc(usersRef, user.user.uid), {
                    firstName: firstName,
                    lastName: lastName,
                    userName: username,
                    imageLink: imageLink,
                    age: parseInt(age),
                    description: description,
                });
                history.push('/home');
            })
            .catch((error) => {
                alert("Either the password is incorrect or the user does not exist.");
            })
    }
    return (
        <Container style={{
            height: '1100px',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-start',
            padding: 0,
            margin: 0,
        }}>
            <Sidebar />
            <Container>

                <Container style={{
                    width: '500px',
                    marginTop: '200px'
                }}>
                    <Typography variant="h3" style={{ paddingLeft: '43px', color: '#A7A7A7' }}>
                        Signup with Lokal
                    </Typography>
                    <Container style={{ marginTop: '30px', height: '400px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="firstName" labelPosition="top">First Name</InputLabel>
                                <Input onChange={(e) => setFirstName(e.target.value)} id="firstName" aria-describedby="firstName" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="lastName">Last Name</InputLabel>
                                <Input onChange={(e) => setLastName(e.target.value)} id="lastName" aria-describedby="lastName" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="imageLink">Image Link</InputLabel>
                                <Input onChange={(e) => setImageLink(e.target.value)} id="imageLink" aria-describedby="imageLink" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="age">Age</InputLabel>
                                <Input onChange={(e) => setAge(e.target.value)} id="age" aria-describedby="age" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="description">Description</InputLabel>
                                <Input onChange={(e) => setDescription(e.target.value)} id="description" aria-describedby="description" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="username">Username</InputLabel>
                                <Input onChange={(e) => setUsername(e.target.value)} id="username" aria-describedby="username" />
                            </FormControl>
                        </Container>
                        <Container>
                            <FormControl fullWidth={true}>
                                <InputLabel shrink={true} htmlFor="password">Password</InputLabel>
                                <Input type="password" onChange={(e) => setPassword(e.target.value)} id="password" aria-describedby="password" />
                            </FormControl>
                        </Container>
                    </Container>
                    <Container style={{ marginTop: '30px', display: 'flex', flexDirection: 'row', justifyContent: 'flex-end' }}>
                        <Button onClick={() => handleRegister()} variant="contained" color="primary">Create Account</Button>
                    </Container>
                </Container>
            </Container>
        </Container>
    );
}