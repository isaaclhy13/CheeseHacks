import React from 'react';
import { Container, FormControl, InputLabel, Typography, Input, Button } from '@material-ui/core';
import Sidebar from './Sidebar';
export default function Playground({ ...props }) {
    return (
        <Container style={{
            height: '900px',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-start',
            padding: 0,
            margin: 0,
        }}>
            <Container style={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-end', background: "red"}}>"HEAder"</Container>
            <Container>
                <Container style={{
                    width: '500px',
                    marginTop: '200px'
                }}>
                    <Typography variant="h3" style={{ paddingLeft: '24px', color: '#A7A7A7' }}>
                        Login with Lokal
                    </Typography>
                    <Container style={{ marginTop: '20px', background: "blue" }}>
                        <FormControl fullWidth={true}>
                            <InputLabel htmlFor="username">Username</InputLabel>
                            <Input id="username" aria-describedby="username" />
                        </FormControl>
                    </Container>
                    <Container>
                        <FormControl fullWidth={true}>
                            <InputLabel htmlFor="password">Password</InputLabel>
                            <Input id="password" aria-describedby="password" />
                        </FormControl>
                    </Container>
                    <Container style={{ marginTop: '30px', display: 'flex', flexDirection: 'row', justifyContent: 'flex-end' }}>
                        <Button variant="outlined" color="primary">Sign Up</Button>
                        <Button style={{ marginLeft: '20px' }} variant="contained" color="primary">Log In</Button>
                    </Container>
                </Container>
            </Container>
        </Container>
    );
}