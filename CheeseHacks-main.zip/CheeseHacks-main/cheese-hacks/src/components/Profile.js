
import dog from '../Stocksy_txpbc184ea5GQw100_Medium_1196298-5af05f1943a10300367b3ecf.jpg'
import garden from '../GettyImages-165831199-56d751df3df78cfb37da972c.jpg'
import lawn from '../When-to-Start-Mowing-in-the-Spring-1024x683.jpeg'
import snow from '../istockphoto-172730009-612x612.jpg'
import plumbing from '../plumbing-basics.jpeg'
import tutoring from '../tutor.jpeg'
import cooking from '../cooking.jpeg'
import companylogo from '../companylogo.PNG'
import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { getDoc, doc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import {
    BrowserRouter as Router,
    Link
} from "react-router-dom";

export default function Profile({ ...props }) {
    const item = []

    const [imageLink, setImageLink] = useState("");
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [age, setAge] = useState(0);
    const [description, setDescription] = useState("");
    useEffect(() => {
        const auth = getAuth();
        if (auth.currentUser === null || auth.currentUser.uid === null) {
            return;
        }

        const docRef = doc(db, "users", auth.currentUser.uid);
        getDoc(docRef)
            .then((d) => {
                setImageLink(d.data().imageLink);
                setFirstName(d.data().firstName);
                setLastName(d.data().lastName);
                setAge(d.data().age);
                setDescription(d.data().description);
            })
    }, []);
    return (
        <div style={{ margin: 0, padding: 0 }}>
            <div style={{ width: '100vw', height: '100vh' }}>
                <div style={{ height: "13vh", width: '100vw', background: '#445768', flexDirection: 'row', display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{ width: '20vw', height: '13vh', flex: 'left', alignItems: 'center', justifyContent: 'center', paddingLeft: '2vw' }}>
                        <img src={companylogo} style={{ width: '13vw', height: '12vh', opacity: 1 }} />
                    </div>
                    <div style={{ width: '60vw', height: '13vh', flex: 'right' }}>
                        <ul style={{ marginTop: 0, height: '13vh', flexDirection: 'row', display: 'flex', justifyContent: 'space-arounds', alignContent: 'center', listStyle: 'none' }}>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Explore">Explore</Link>
                            </li>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Home">Dashboard</Link>
                            </li>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/CreateJobs">Create a Job</Link>
                            </li>
                            <li style={{ width: '15vw', height: '13vh', justifyContent: 'center', display: 'flex', alignItems: 'center' }}>
                            <Link style={{color: 'white', fontSize:'3vh',textDecoration:'none'}} to="/Profile">Profile</Link>
                            </li>
                        </ul>
                    </div>
                </div>

                <div style={{ width: '85vw', height: '87vh', marginLeft: '7.5vw', marginRight: '7.5vw', paddingTop: '3vh', display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                    <div style={{ height: '80vh', width: '40vw', background: '#EBF1F5', borderRadius: '2vw', boxShadow: "1vw 1vw 1.5vw #C5C5C5" }}>
                        <div style={{ height: '80vh', width: '40vw', display: 'flex', flexDirection: "column" }}>
                            <div style={{ width: '40vw', height: '80vh', display: 'flex', justifyContent: 'center', alignItems: 'center', borderTopLeftRadius: '2vw' }}>
                                <img src={imageLink} style={{ width: '40vw', height: '80vh', objectFit: 'cover', borderRadius: '2vw' }} />
                            </div>
                            <div style={{ position: 'absolute', bottom: '5vh' }}>
                                <div style={{ display: 'flex', flexDirection: 'row' }}>
                                    <h1 style={{ paddingLeft: '2vw', color: 'white' }}>{firstName + " " + lastName}  </h1>
                                    <h1 style={{ fontWeight: 300, paddingLeft: '1vw', color: 'white' }}>{age}</h1>

                                </div>
                                <p style={{ paddingLeft: '2vw', fontSize: '1Vw', margin: 0, color: 'white' }}>Madson, WI</p>
                                <div style={{ display: 'flex', flexDirection: 'row', width: '37vw' }}>
                                    <p style={{ paddingLeft: '2vw', fontSize: '1.3vw', color: 'white', fontWeight: 600 }}>" {description} " </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style={{ height: '80vh', width: '40vw', justifyContent: 'space-between', flexDirection: 'column', display: 'flex', }}>
                        <div style={{ height: '37vh', width: '40vw', background: '#EBF1F5', borderRadius: '2vw', boxShadow: "1vw 1vw 1vw #c5c5c5" }} >
                            <h3 style={{ color: '#445768', paddingLeft: '2vw', margin: '1.5vh' }}>Jobs near me </h3>
                            <ul style={{ height: '35vh', width: '40vw', listStyle: 'none', flexDirection: 'row', display: 'flex', paddingLeft: 0, overflow: 'scroll', }}>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw' }}>
                                    <img src={dog} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7, objectFit: "cover" }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '1.9vw' }}>Dog Walking</p>
                                </li>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw' }}>
                                    <img src={garden} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7 }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '2.9vw' }}>Gardening</p>
                                </li>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw' }}>
                                    <img src={lawn} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7, }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '1.5vw' }}>Lawn Mowing</p>

                                </li>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw', marginRight: '1vw' }}>
                                    <img src={snow} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7, }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '1.1vw' }}>Christmas Lights</p>

                                </li>
                            </ul>
                        </div>
                        <div style={{ height: '37vh', width: '40vw', background: '#EBF1F5', borderRadius: '2vw', boxShadow: "1vw 1vw 1vw #c5c5c5" }}>
                            <h3 style={{ color: '#445768', paddingLeft: '2vw', margin: '1.5vh' }}>Jobs you may like </h3>
                            <ul style={{ height: '35vh', width: '40vw', listStyle: 'none', flexDirection: 'row', display: 'flex', paddingLeft: 0, overflow: 'scroll', }}>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw' }}>
                                    <img src={plumbing} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7, objectFit: "cover" }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '3.2vw' }}>Plumbing</p>
                                </li>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw' }}>
                                    <img src={tutoring} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7 }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '3.2vw' }}>Tutoring</p>
                                </li>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw' }}>
                                    <img src={cooking} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7, }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '3.5vw' }}>Cooking</p>

                                </li>
                                <li style={{ width: '12vw', height: '13vw', background: 'black', borderRadius: '1vw', position: 'relative', marginLeft: '1vw', marginRight: '1vw' }}>
                                    <img src={snow} style={{ width: '12vw', height: '13vw', borderRadius: '1vw', opacity: 0.7, }} />
                                    <p style={{ color: 'white', position: 'absolute', bottom: 0, fontSize: '1.5vw', left: '1.1vw' }}>Christmas Lights</p>

                                </li>
                            </ul>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    );
}
