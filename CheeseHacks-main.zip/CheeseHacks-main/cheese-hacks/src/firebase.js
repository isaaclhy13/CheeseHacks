import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';


const app = initializeApp({
    apiKey: "AIzaSyBGPT9TRLAKvAaMDRHh3qtQEHqi2HODQS4",
    authDomain: "cheesehacks-7b5fd.firebaseapp.com",
    projectId: "cheesehacks-7b5fd",
    storageBucket: "cheesehacks-7b5fd.appspot.com",
    messagingSenderId: "793207650784",
    appId: "1:793207650784:web:d513455a223856179e9385",
    measurementId: "G-4Z7HLJNMLW"
});

export const db = getFirestore(app);
